# Daraja-2.0-B2C-Intergration👨‍💻
made with 💖 BY Langat Fortune
edit the credentials in stk_initiate.php and it will work perfectly😎🌈
